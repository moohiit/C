
//Write a program to check the year is leap or not.
#include<stdio.h>
int main()
{
    int year;
    printf("Enter Your Year : ");
    scanf("%d",&year);
    if (year%400==0)
    {
        printf("%d is Leap Year",year);
    }else if (year%100==0)
    {
        printf("%d is not a Leap Year",year);
    }else if (year%4==0)
    {
        printf("%d is Leap Year",year);
    }else{
        printf("%d is not a Leap Year",year);
    }
    return 0;
}